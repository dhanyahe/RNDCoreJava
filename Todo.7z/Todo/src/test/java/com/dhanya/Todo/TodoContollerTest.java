package com.dhanya.Todo;


import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
//import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.dhanya.Todo.model.Todo;
import com.dhanya.Todo.service.ToDoService;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class TodoContollerTest {

	private MockMvc mockmvc;
	
	@Autowired
	private ToDoService ts;
	
	@Autowired
	 private WebApplicationContext wac;
	
	@Before
	public void setup() {
		this.mockmvc=MockMvcBuilders.webAppContextSetup(wac).build();
		
	}
	
	
	@Test
	public void test_get_all_todos() throws Exception {
	    List<Todo> todos = Arrays.asList(
	            new Todo(1L, "abc",true),
	            new Todo(2L, "cde",false));
	    when(ts.getAllToDo()).thenReturn(todos);
	    mockmvc.perform(get("/todo"))
	            .andExpect(status().isOk())
	            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
	            .andExpect(jsonPath("$", hasSize(2)))
	            .andExpect(jsonPath("$[0].id", is(1L)))
	            .andExpect(jsonPath("$[0].text", is("abc")))
	            .andExpect(jsonPath("$[0].completed", is(true)))
	            .andExpect(jsonPath("$[1].id", is(2L)))
	            .andExpect(jsonPath("$[1].text", is("cde")))
	            .andExpect(jsonPath("$[1].completed", is(false)));
	    verify(ts, times(1)).getAllToDo();
	    verifyNoMoreInteractions(ts);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	 * @Test public void TestgetAllToDo() throws Exception {
	 * mockmvc.perform(MockMvcRequestBuilders.get("/todo").accept(MediaType.
	 * APPLICATION_JSON)) .andExpect(jsonPath("$", hasSize(5))).andDo(print());
	 * 
	 * }
	 * 
	 * @Test public void TestSaveToDo() throws Exception {
	 * mockmvc.perform(MockMvcRequestBuilders.post("/todo")
	 * .contentType(MediaType.APPLICATION_JSON)
	 * .content("{\"text\" : \"New ToDo Sample\", \"completed\" : \"false\" }")
	 * .accept(MediaType.APPLICATION_JSON)) //.andExpect(jsonPath("$.id").exists())
	 * .andExpect(jsonPath("$.text").exists())
	 * .andExpect(jsonPath("$.completed").exists())
	 * //.andExpect(jsonPath("$.id").value(1))
	 * .andExpect(jsonPath("$.text").value("New ToDo Sample"))
	 * .andExpect(jsonPath("$.completed").value(false)) .andDo(print()); }
	 * 
	 * @Test public void TestUpdateToDo() throws Exception {
	 * mockmvc.perform(MockMvcRequestBuilders.put("/todo")
	 * .contentType(MediaType.APPLICATION_JSON)
	 * .content("{ \"id\": \"1\", \"text\" : \"New ToDo Text\", \"completed\" : \"false\" }"
	 * ) .accept(MediaType.APPLICATION_JSON)) .andExpect(jsonPath("$.id").exists())
	 * .andExpect(jsonPath("$.text").exists())
	 * .andExpect(jsonPath("$.completed").exists())
	 * .andExpect(jsonPath("$.id").value(1))
	 * .andExpect(jsonPath("$.text").value("New ToDo Text"))
	 * .andExpect(jsonPath("$.completed").value(false)) .andDo(print()); }
	 * 
	 * @Ignore public void TestDeleteToDo() throws Exception {
	 * mockmvc.perform(MockMvcRequestBuilders.delete("/todo/2").accept(MediaType.
	 * APPLICATION_JSON)) .andExpect(jsonPath("$.status").value(200))
	 * //.andExpect(jsonPath("$.message").value("ToDo has been deleted"))
	 * .andDo(print()); }
	 */
	
	
	
	
	
	

}

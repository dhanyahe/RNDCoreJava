package com.dhanya.Todo;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.dhanya.Todo.model.Todo;
import com.dhanya.Todo.repository.ToDoRepository;
import com.dhanya.Todo.service.ToDoServiceImpl;

public class TodoServiceTest {

	@Mock
	private ToDoRepository tr;
	
	@InjectMocks
	private ToDoServiceImpl tsI;
	
	@Before
	public void setup() {

		MockitoAnnotations.initMocks(this);
		
	}
	
	@Test
	public void testGetAllToDo() {
		List<Todo> testList=new ArrayList<Todo>();
		testList.add(new Todo(1,"todo 1",true));
		testList.add(new Todo(2,"todo 2",true));
		when(tr.findAll()).thenReturn(testList);
		List<Todo> result=tsI.getAllToDo();
		assertEquals(2,result.size());
	}
	
	@Test
	public void testGetToDoById() {
		Todo test=new Todo(1,"todo 1",true);
		when(tr.getById(1L)).thenReturn(test);
		Todo result=tsI.getToDoById(1);
		assertEquals(1,result.getId());
		assertEquals("todo 1",result.getText());
		assertEquals(true,result.isCompleted());
	}
	
	@Test
	public void testSaveToDo() {
		Todo test=new Todo(5,"todo 5",false);
		when(tr.save(test)).thenReturn(test);
		Todo result = tsI.saveToDo(test);
		assertEquals(5,result.getId());
		assertEquals("todo 5",result.getText());
		assertEquals(false,result.isCompleted());
	}
	
	@Test
	public void testRemoveToDo() {
		Todo test=new Todo(1,"todo 1",true);
		tsI.removeToDo(test);
		 verify(tr, times(1)).delete(test);
	}
	
	
	
}

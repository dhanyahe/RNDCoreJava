package com.dhanya.Todo.service;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.dhanya.Todo.model.Todo;


@Scope(value = "session")
@Component(value = "todoService")
public interface ToDoService {
	public List<Todo> getAllToDo();
	public Todo getToDoById(long id);
	public Todo saveToDo(Todo todo);
	public void removeToDo(Todo todo);
	
}


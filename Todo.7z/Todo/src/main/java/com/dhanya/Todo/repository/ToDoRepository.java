package com.dhanya.Todo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dhanya.Todo.model.Todo;


@Repository("toDoRepository")
public interface ToDoRepository extends JpaRepository<Todo, Long>{

	Todo getById(long id);

	

	

	
}

package com.dhanya.Todo.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dhanya.Todo.model.Todo;
import com.dhanya.Todo.service.ToDoService;

@RestController
public class ToDoController {

	private static final Logger logger = LoggerFactory.getLogger(ToDoController.class);

	@Autowired
	public ToDoService ts;

	@RequestMapping(value = "/todo", method = RequestMethod.GET)
	public ResponseEntity<List<Todo>> getAllToDo() {

		return new ResponseEntity<List<Todo>>(ts.getAllToDo(), HttpStatus.OK);
	}

	
	 @RequestMapping(value = "/todo/{id}", method = RequestMethod.GET)
	 public ResponseEntity<Todo> getToDoById(@PathVariable("id") long id) {
	  logger.info("Todo id to return " + id); return new
	  ResponseEntity<Todo>(ts.getToDoById(id), HttpStatus.OK); }
	  
	  @RequestMapping(value = "/todo", method = RequestMethod.POST) 
	  public void saveToDo(@RequestBody Todo payload) {
	  logger.info("Payload to save" + payload); 
	  ts.saveToDo(payload);
	  }
	  
	  @RequestMapping(value = "/todo/{id}", method = RequestMethod.DELETE) public
	  void removeToDo(@PathVariable("id") long id) {
	  logger.info("Todo id to be removed" + id); Todo t = ts.getToDoById(id);
	  ts.removeToDo(t); }
	  
	  @RequestMapping(value = "/todo", method = RequestMethod.PUT) public
	  ResponseEntity<Todo> update(@RequestBody Todo payload) {
	  logger.info("Todo payload to be updated" + payload); return new
	  ResponseEntity<Todo>(ts.saveToDo(payload), HttpStatus.OK); }
	 

}

package com.dhanya.Todo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dhanya.Todo.model.Todo;
import com.dhanya.Todo.repository.ToDoRepository;

@Component
public class ToDoServiceImpl implements ToDoService {

	
	@Autowired
	public ToDoRepository tr;
	
	
	
	@Override
	public Todo getToDoById(long id) {
		if(id>0)
		return tr.getById(id);
		else 
			return null;
	}

	@Override
	public Todo saveToDo(Todo t) {
		
		return tr.save(t);
	}

	@Override
	public void removeToDo(Todo t) {
		tr.delete(t);
		
	}

	@Override
	public List<Todo> getAllToDo() {
		// TODO Auto-generated method stub
		return tr.findAll();
	}

}

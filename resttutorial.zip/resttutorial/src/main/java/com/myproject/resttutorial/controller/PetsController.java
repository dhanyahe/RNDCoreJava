package com.myproject.resttutorial.controller;

import java.util.List;

import javax.validation.Valid;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.myproject.resttutorial.models.Pets;
import com.myproject.resttutorial.repository.PetsRepository;

@RestController
@RequestMapping("/pets")
public class PetsController {
	
	@Autowired
	private PetsRepository repository;
	
	//===================== GET Methods==================================
	@RequestMapping(value="/",method=RequestMethod.GET)
	public List<Pets> getAllPets() {
		return repository.findAll();
		
	}
	
	
	@RequestMapping(value="/{id}",method=RequestMethod.GET)
	public Pets getPetById(@PathVariable("id") ObjectId id) {
		
		return repository.findBy_id(id);
	}
	
	//================= PUT(update) Method ==============================
	
	@RequestMapping(value="/{id}",method=RequestMethod.PUT)
	public void modifyPetById(@PathVariable("id") ObjectId id ,@Valid @RequestBody Pets pet) {
		pet.set_id(id);
		repository.save(pet);
				
	}
	
	//================ POST(insert) Method =======================
	
	@RequestMapping(value="/",method=RequestMethod.POST)
	public Pets createPet(@Valid @RequestBody Pets pet) {
		pet.set_id(ObjectId.get());
		repository.save(pet);
		return pet;
	}
	
	//=================== DELETE Method ==============================
	
	@RequestMapping(value="/{id}",method=RequestMethod.DELETE)
	public void deletePet(@PathVariable ObjectId id) {
		//repository.deleteBy_id(id);
		repository.delete(repository.findBy_id(id));
	}
	
	


}

package com.dhanya.AuthenticationMicroservice;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AuthenticationMicroserviceApplicationTests {

	@Test
	public void contextLoads() {
	}
	
	@Test
	public void test1() {
		int n=10;
		String name="Dan";
		String x=null;
		
		
		assertEquals(10,n);
		assertFalse(5>n);
		assertNotNull(x);
		
		
	}

}

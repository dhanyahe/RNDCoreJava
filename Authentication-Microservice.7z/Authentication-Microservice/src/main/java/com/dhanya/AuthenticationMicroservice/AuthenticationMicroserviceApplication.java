package com.dhanya.AuthenticationMicroservice;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

@SpringBootApplication
public class AuthenticationMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthenticationMicroserviceApplication.class, args);
		Result result=JUnitCore.runClasses(AuthenticationMicroserviceApplicationTests.class);
		
		for(Failure failure:result.getFailures()) {
			System.out.println(failure.toString());
			}
		
		System.out.println(result.wasSuccessful());
	}

}

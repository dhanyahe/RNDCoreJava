package com.dhanya.AuthenticationMicroservice.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/testauth")
public class TestAuthController {
	
	@RequestMapping("/")
	public String testauth() {
		return "Hey!! You are Authenticated";
	}

}

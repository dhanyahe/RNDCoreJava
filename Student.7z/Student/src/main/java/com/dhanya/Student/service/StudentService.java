package com.dhanya.Student.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

import com.dhanya.Student.model.Course;
import com.dhanya.Student.model.Student;

@Component
public class StudentService implements StudentServiceInf{
	
	private static List<Student> students= new ArrayList<>();
	
	
	static {
		
		Course course1 = new Course("Course1", "Spring", "10 Steps", Arrays
				.asList("Learn Maven", "Import Project", "First Example",
						"Second Example"));
		Course course2 = new Course("Course2", "Spring MVC", "10 Examples",
				Arrays.asList("Learn Maven", "Import Project", "First Example",
						"Second Example"));
		Course course3 = new Course("Course3", "Spring Boot", "6K Students",
				Arrays.asList("Learn Maven", "Learn Spring",
						"Learn Spring MVC", "First Example", "Second Example"));
		Course course4 = new Course("Course4", "Maven",
				"Most popular maven course on internet!", Arrays.asList(
						"Pom.xml", "Build Life Cycle", "Parent POM",
						"Importing into Eclipse"));

		Student ranga = new Student("Student1", "Ranga Karanam",
				"Hiker, Programmer and Architect", new ArrayList<>(Arrays
						.asList(course1, course2, course3, course4)));

		Student satish = new Student("Student2", "Satish T",
				"Hiker, Programmer and Architect", new ArrayList<>(Arrays
						.asList(course1, course2, course3, course4)));

		students.add(ranga);
		students.add(satish);
	}
	
	@Override
	public List<Student> getAllStudents(){
		return students;
	}
	
	@Override
	public Student getStudentById(String id) {
		for(Student s:students) {
				if(s.getId().equals(id)) {
				return s;}}
		return null;
	}
	
	@Override
	public List<Course> getAllCourses(String sId){
		Student s=getStudentById(sId);
		return s.getCourses();
	}
	
	@Override
	public Course getCourseById(String sId,String cId) {
		Student s=getStudentById(sId);
		for(Course c:s.getCourses()) {
			if(c.getId().equals(cId)) {
				return c;
			}
			
		}
		return null;
	}
	
	

	
	
	

}

package com.dhanya.Student.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.dhanya.Student.model.Course;
import com.dhanya.Student.model.Student;

@Component
public interface StudentServiceInf {
	
	public List<Student> getAllStudents();
	public Student getStudentById(String id);
	public List<Course> getAllCourses(String sId);
	public Course getCourseById(String sId,String cId);

}

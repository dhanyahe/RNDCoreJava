package com.resale.webservice.controller;

import org.springframework.web.servlet.ModelAndView;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.cloud.client.discovery.DiscoveryClient;



/*import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;*/


@RestController
public class WebController {
	
	
	@Autowired
	private DiscoveryClient discoveryClient;
	
	@GetMapping("/home")
	public ModelAndView homePage()
	{
		ModelAndView mav=new ModelAndView("index");
		return mav;
	}
	
	@RequestMapping(value="/getUserByEmail", method = RequestMethod.POST)
	public String getUser(@RequestParam String email)
	{
		System.out.println(email);
		List<ServiceInstance> instances=discoveryClient.getInstances("user-service");
		ServiceInstance serviceInstance=instances.get(0);
		
		//ServiceInstance serviceInstance=loadBalancer.choose("employee-producer");

		System.out.println(serviceInstance.getUri());
		
		String baseUrl=serviceInstance.getUri().toString();
		baseUrl = baseUrl+"/getuser/"+email;
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response=null;
		try{
		response=restTemplate.exchange(baseUrl,
				HttpMethod.GET, getHeaders() ,String.class);
		}catch (Exception ex)
		{
			System.out.println(ex);
		}
		return response.getBody();
	}

	private static HttpEntity<?> getHeaders() throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity<>(headers);
	}
	
	
	@GetMapping("/register")
	public ModelAndView registerPage()
	{
		ModelAndView mav=new ModelAndView("register");
		return mav;
	}
	
	@GetMapping("/")
	public String test()
	{
		return "hello";
	}
	

}

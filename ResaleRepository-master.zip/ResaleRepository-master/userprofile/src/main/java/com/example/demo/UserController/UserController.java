package com.example.demo.UserController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.UserModel.UserProfile;

import com.example.demo.UserService.UserService;

@RestController
public class UserController {
	
	@Autowired
	private UserService userService;
	

	/*@RequestMapping(value="/signup", method=RequestMethod.GET)
	public ModelAndView signup() {
		ModelAndView mav = new ModelAndView("signup");
		return mav;
	}*/
	/*@RequestMapping(value="/update", method=RequestMethod.GET)
	public ModelAndView update() {
		ModelAndView mav = new ModelAndView("update");
		return mav;
	}*/
	@RequestMapping("/getuser/{email}")
	public UserProfile findByEmail(@PathVariable("email") final String email) {
	
		 return userService.findByEmail(email);
	}
	@RequestMapping(value="/signup", method = RequestMethod.POST)
	public UserProfile create(Model model, @ModelAttribute("userprofile") UserProfile userprofile, @ModelAttribute("name")String name, @ModelAttribute("password1")String password, @ModelAttribute("phone")String phone, @ModelAttribute("email")String email, @ModelAttribute("address")String address,@ModelAttribute("paid")boolean paid) {
//		if((userService.findByEmail(email) == null) && (userService.findByPhone(name) == null)) {
			UserProfile user= userService.create(name, password, phone, email, address,paid);
			return user;
		}
		/*else {
			
			ModelAndView mav = new ModelAndView(); 
			model.addAttribute("msg", "email is already exist");
			mav.setViewName("signup");
			return mav;
		}
	}*/
	@RequestMapping(value="/update", method = RequestMethod.POST)
	public ModelAndView update(Model model, @ModelAttribute("userprofile") UserProfile userprofile, @ModelAttribute("name")String name, @ModelAttribute("password1")String password, @ModelAttribute("phone")String phone, @ModelAttribute("email")String email, @ModelAttribute("address")String address,@ModelAttribute("paid")boolean paid) {
		
			UserProfile userprofile1= userService.update(name, password, phone, email, address,paid);
			ModelAndView mav = new ModelAndView(); 
			mav.addObject("profiledata", userprofile1);
			mav.setViewName("registered");
			return mav;
		}

	
}

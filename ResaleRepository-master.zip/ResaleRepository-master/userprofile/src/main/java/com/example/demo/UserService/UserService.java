package com.example.demo.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.UserModel.UserProfile;
import com.example.demo.UserRepository.UserRepository;

@Service
public class UserService {


		@Autowired
		private UserRepository userRepository;
		
		public UserProfile create(String name, String password, String phone, String email, String address,boolean paid) {
			
			if(findByEmail(email)==null && findByPhone(phone)==null)
			return userRepository.save(new UserProfile(name,password,phone,email,address,paid));
			else
				return null;
		}
		
		public UserProfile update(String name, String password, String phone, String email, String address,boolean paid) {
			
			UserProfile userprofile=userRepository.findByEmail(email);
			userprofile.setName(name);
			userprofile.setPassword(password);
			userprofile.setEmail(email);
			userprofile.setPhone(phone);
			userprofile.setAddress(address);
			userprofile.setPaid(paid);
			return userRepository.save(userprofile);
		}
		public void delete(String email) {
		UserProfile userprofile=userRepository.findByEmail(email);
		userRepository.delete(userprofile);
		}
		public UserProfile findByEmail(String email) {
			return userRepository.findByEmail(email);
		}
		
		public UserProfile findByPhone(String phone) {
			return userRepository.findByPhone(phone);
		}
		
}
